from utils.database import init_db
print("Executing init_db()...")
init_db()
print("Done.")
