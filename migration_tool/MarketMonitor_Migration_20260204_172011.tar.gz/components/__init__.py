# -*- coding: utf-8 -*-
"""
components 模块初始化
"""
from components.sidebar import render_sidebar

__all__ = ['render_sidebar']
